package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CollegemanagementspringbootapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CollegemanagementspringbootapplicationApplication.class, args);
	}

}
